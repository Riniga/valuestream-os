# SOP 1: Backlog refinement

## 1. Syfte
Förbereda och förtydliga backloggen så att arbetet är redo för planering och effektiv genomförande.

## 2. Kontext
- Processteg: Leverans
- Delprocess: Backlog refinement

## 3. Input
- Prioriterad backlog (epics, features, stories)
- Feedback från föregående iteration
- Tekniska insikter och beroenden

## 4. Output
- Förtydligade user stories
- Ready-markerad backlog

## 5. RACI
- R: Business Analyst
- A: Produktägare
- C: Utvecklare
- I: Lösningsarkitekt

## 6. Arbetssteg
1. Gå igenom prioriterad backlog och identifiera stories för kommande arbete.  
2. Förtydliga user stories i dialog med utvecklingsteamet.  
3. Bryt ner stories i mindre delar vid behov.  
4. Definiera och komplettera acceptance criteria.  
5. Säkerställ att stories uppfyller definition of ready (t.ex. INVEST).  
6. Identifiera tekniska beroenden och risker kopplade till stories.  
7. Estimera stories tillsammans med utvecklingsteamet.  
8. Markera stories som “ready” i backloggen.  
9. Fastställ ready-backlog (beslut av A).