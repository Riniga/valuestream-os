# SOP 3: Samla input för uppdaterad kravställning

## 1. Syfte
Samla och strukturera relevant input inför nästa kravställning utan att förändra krav i detta steg.

## 2. Kontext
- Processteg: Repeat
- Delprocess: Samla input för uppdaterad kravställning

## 3. Input
- Sammanställd utvärdering av leveransen
- Retrospektivrapport
- Verksamhetsfeedback
- Ej levererade funktioner
- Nya behov från användare
- Lista på revideringsbehov av krav

## 4. Output
- Input-paket till Kravställning

## 5. RACI
- R: Business Analyst
- A: Produktägare
- C: Verksamhetsexperter
- I: Utvecklare

## 6. Arbetssteg
1. Samla och strukturera input från utvärdering och retrospektiv.  
2. Sammanställ verksamhetsfeedback och nya behov från användare.  
3. Identifiera krav som behöver revideras eller prioriteras om.  
4. Identifiera ej levererade funktioner som ska tas vidare.  
5. Strukturera input i ett tydligt och spårbart format.  
6. Säkerställ att inga krav förändras i detta steg (endast insamling).  
7. Validera input med produktägare.  
8. Fastställ input-paket till nästa kravställning (beslut av A).